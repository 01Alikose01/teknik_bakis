import requests

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'tr-TR,tr;q=0.9',
    'Referer': 'https://www.kap.org.tr/tr/Bildirim/Ozel',
    'Origin': 'https://www.kap.org.tr',
}

# Test 1: JSON API
urls = [
    'https://www.kap.org.tr/tr/api/disclosures?orderBy=publishDate&orderDir=desc&pageSize=5&pageIndex=0',
    'https://www.kap.org.tr/tr/api/disclosures/public?pageSize=5',
    'https://www.kap.org.tr/tr/api/disclosures',
]

for url in urls:
    try:
        r = requests.get(url, headers=headers, timeout=15)
        print(f'STATUS {r.status_code}: {url[-60:]}')
        if r.status_code == 200:
            print('  CONTENT:', r.text[:300])
    except Exception as e:
        print(f'HATA: {e}')

# Test 2: HTML sayfasından bildirimler
try:
    r2 = requests.get('https://www.kap.org.tr/tr/Bildirim/Ozel', headers=headers, timeout=15)
    print(f'\nHTML STATUS: {r2.status_code}')
    if r2.status_code == 200:
        import re
        # JSON data bul
        matches = re.findall(r'"title":"([^"]{10,80})"', r2.text[:5000])
        print('Bulunan başlıklar:', matches[:5])
except Exception as e:
    print(f'HTML HATA: {e}')
