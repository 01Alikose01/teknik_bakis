class AssetModel {
  final String symbol;
  final String name;
  double price;
  double changePercent;
  double open;
  double high;
  double low;
  List<double> prices;
  List<double> volumes;

  AssetModel({
    required this.symbol,
    required this.name,
    this.price = 0,
    this.changePercent = 0,
    this.open = 0,
    this.high = 0,
    this.low = 0,
    this.prices = const [],
    this.volumes = const [],
  });

  // EMA hesaplama — sonuç prices ile aynı uzunlukta değil, period-1 kısa
  List<double> ema(int period) {
    if (prices.length < period) return [];
    final k = 2.0 / (period + 1);
    final result = <double>[];
    double emaVal = prices.take(period).reduce((a, b) => a + b) / period;
    result.add(emaVal);
    for (int i = period; i < prices.length; i++) {
      emaVal = prices[i] * k + emaVal * (1 - k);
      result.add(emaVal);
    }
    return result; // length = prices.length - period + 1
  }

  // ATR hesaplama
  List<double> atr({int period = 14}) {
    if (prices.length < period + 1) return [];
    final trs = <double>[];
    for (int i = 1; i < prices.length; i++) {
      trs.add((prices[i] - prices[i - 1]).abs());
    }
    final result = <double>[];
    double atrVal = trs.take(period).reduce((a, b) => a + b) / period;
    result.add(atrVal);
    for (int i = period; i < trs.length; i++) {
      atrVal = (atrVal * (period - 1) + trs[i]) / period;
      result.add(atrVal);
    }
    return result;
  }

  // Supertrend (factor=3, period=14)
  Map<String, List<double>> supertrend({int period = 14, double factor = 3.0}) {
    final atrVals = atr(period: period);
    if (atrVals.isEmpty) {
      return {'upper': [], 'lower': [], 'trend': [], 'direction': []};
    }
    final offset = prices.length - atrVals.length;
    final upper = <double>[];
    final lower = <double>[];
    final trend = <double>[];
    final direction = <double>[];

    double prevUpper = 0, prevLower = 0, prevTrend = prices[offset];

    for (int i = 0; i < atrVals.length; i++) {
      final idx = i + offset;
      final hl2 = prices[idx];
      final band = factor * atrVals[i];
      double upperBand = hl2 + band;
      double lowerBand = hl2 - band;

      if (i > 0) {
        upperBand = (upperBand < prevUpper || prices[idx - 1] > prevUpper) ? upperBand : prevUpper;
        lowerBand = (lowerBand > prevLower || prices[idx - 1] < prevLower) ? lowerBand : prevLower;
      }

      double dir, trendVal;
      if (i == 0) {
        dir = 1;
        trendVal = lowerBand;
      } else if (prevTrend == prevUpper) {
        dir = prices[idx] > upperBand ? 1 : -1;
        trendVal = dir == 1 ? lowerBand : upperBand;
      } else {
        dir = prices[idx] < lowerBand ? -1 : 1;
        trendVal = dir == 1 ? lowerBand : upperBand;
      }

      upper.add(upperBand);
      lower.add(lowerBand);
      trend.add(trendVal);
      direction.add(dir);
      prevUpper = upperBand;
      prevLower = lowerBand;
      prevTrend = trendVal;
    }
    return {'upper': upper, 'lower': lower, 'trend': trend, 'direction': direction};
  }

  // RSI — Wilder's Smoothed RSI (endüstri standardı)
  List<double> rsi({int period = 14}) {
    if (prices.length < period + 1) return [];

    // İlk period bardan başlangıç ortalamalarını hesapla
    double avgGain = 0, avgLoss = 0;
    for (int i = 1; i <= period; i++) {
      final diff = prices[i] - prices[i - 1];
      if (diff > 0) { avgGain += diff; } else { avgLoss -= diff; }
    }
    avgGain /= period;
    avgLoss /= period;

    final result = <double>[];
    // İlk RSI değeri
    if (avgLoss == 0) {
      result.add(100);
    } else {
      result.add(100 - (100 / (1 + avgGain / avgLoss)));
    }

    // Wilder smoothing ile devam et
    for (int i = period + 1; i < prices.length; i++) {
      final diff = prices[i] - prices[i - 1];
      final gain = diff > 0 ? diff : 0.0;
      final loss = diff < 0 ? -diff : 0.0;
      avgGain = (avgGain * (period - 1) + gain) / period;
      avgLoss = (avgLoss * (period - 1) + loss) / period;
      if (avgLoss == 0) {
        result.add(100);
      } else {
        result.add(100 - (100 / (1 + avgGain / avgLoss)));
      }
    }
    return result;
  }

  // MACD (12, 26, 9)
  Map<String, List<double>> macd() {
    final ema12 = ema(12);
    final ema26 = ema(26);
    if (ema12.isEmpty || ema26.isEmpty) return {'macd': [], 'signal': [], 'hist': []};
    // ema12.length = prices.length - 11
    // ema26.length = prices.length - 25
    // ema12 daha uzun, hizalamak için ema12'nin sondan ema26.length kadarını al
    final alignedEma12 = ema12.sublist(ema12.length - ema26.length);
    final macdLine = List.generate(ema26.length, (i) => alignedEma12[i] - ema26[i]);

    if (macdLine.length < 9) return {'macd': macdLine, 'signal': [], 'hist': []};
    final k = 2.0 / 10;
    double sigVal = macdLine.take(9).reduce((a, b) => a + b) / 9;
    final signal = <double>[sigVal];
    for (int i = 9; i < macdLine.length; i++) {
      sigVal = macdLine[i] * k + sigVal * (1 - k);
      signal.add(sigVal);
    }
    // signal daha kısa, hizala
    final alignedMacd = macdLine.sublist(macdLine.length - signal.length);
    final hist = List.generate(signal.length, (i) => alignedMacd[i] - signal[i]);
    return {'macd': macdLine, 'signal': signal, 'hist': hist};
  }

  // ---- Sinyal özellikleri ----

  bool get isSupertrendBuy {
    final dir = supertrend()['direction'] ?? [];
    if (dir.length < 2) return false;
    return dir[dir.length - 2] == -1 && dir.last == 1;
  }

  bool get isSupertrendSell {
    final dir = supertrend()['direction'] ?? [];
    if (dir.length < 2) return false;
    return dir[dir.length - 2] == 1 && dir.last == -1;
  }

  double get supertrendDirection {
    final dir = supertrend()['direction'] ?? [];
    return dir.isEmpty ? 0 : dir.last;
  }

  // Golden Cross: EMA20, EMA50'yi bir önceki bar negatif, bu bar pozitif kesti
  bool get isGoldenCross {
    final e20 = ema(20); // length = prices.length - 19
    final e50 = ema(50); // length = prices.length - 49
    if (e20.length < 2 || e50.length < 2) return false;
    // Ortak son 2 değeri al
    final e20Prev = e20[e20.length - 2];
    final e20Curr = e20.last;
    final e50Prev = e50[e50.length - 2];
    final e50Curr = e50.last;
    return (e20Prev - e50Prev) < 0 && (e20Curr - e50Curr) >= 0;
  }

  // Death Cross: EMA20, EMA50'yi bir önceki bar pozitif, bu bar negatif kesti
  bool get isDeathCross {
    final e20 = ema(20);
    final e50 = ema(50);
    if (e20.length < 2 || e50.length < 2) return false;
    final e20Prev = e20[e20.length - 2];
    final e20Curr = e20.last;
    final e50Prev = e50[e50.length - 2];
    final e50Curr = e50.last;
    return (e20Prev - e50Prev) > 0 && (e20Curr - e50Curr) <= 0;
  }

  bool get isRsiBelow40 {
    final r = rsi();
    return r.isNotEmpty && r.last <= 40;
  }

  bool get isMacdBullish {
    final hist = macd()['hist'] ?? [];
    if (hist.length < 2) return false;
    return hist[hist.length - 2] < 0 && hist.last >= 0;
  }

  // EMA durumu (fiyat ile karşılaştırma)
  bool emaAbovePrice(int period) {
    final e = ema(period);
    return e.isNotEmpty && price > e.last;
  }

  // 52 hafta yüksek/düşük (yaklaşık — son 252 günlük veri)
  double get high52w => prices.isEmpty ? 0 : prices.reduce((a, b) => a > b ? a : b);
  double get low52w  => prices.isEmpty ? 0 : prices.reduce((a, b) => a < b ? a : b);

  // Toplam hacim ortalaması
  double get avgVolume {
    if (volumes.isEmpty) return 0;
    return volumes.reduce((a, b) => a + b) / volumes.length;
  }
}
