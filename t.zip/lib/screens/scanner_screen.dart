import 'package:flutter/material.dart';
import '../models/asset_model.dart';
import '../services/stock_service.dart';
import 'buy_screen.dart';

class ScannerScreen extends StatefulWidget {
  const ScannerScreen({super.key});

  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String? _selectedFilter;
  List<AssetModel> _results = [];
  bool _scanning = false;
  int _progress = 0;
  int _total = 0;
  String? _errorMsg;
  String _activePeriod = 'G';

  static final List<String> _scanSymbols =
      kBistStocks.take(100).map((e) => e['symbol']!).toList();

  static const List<_FilterDef> _trendFilters = [
    _FilterDef(
      id: 'MACD Bullish',
      label: 'MACD',
      subtitle: 'Koşul: MACD çizgisi sinyal çizgisini yukarı keser → Alım sinyali, pozitif momentum oluşturur.',
      color: Color(0xFF34C759),
      icon: Icons.show_chart,
    ),
    _FilterDef(
      id: 'Golden Cross',
      label: 'EMA Kesişimi',
      subtitle: 'Koşul: Kısa vadeli EMA (örn: EMA 20), uzun vadeli olanı (örn: EMA 50) yukarı yönde kestiğinde \'Golden Cross\' olarak bilinen güçlü bir yükseliş sinyali oluşur.',
      color: Color(0xFF86C232),
      icon: Icons.trending_up,
    ),
    _FilterDef(
      id: 'Death Cross',
      label: 'Death Cross',
      subtitle: 'Koşul: EMA20, EMA50\'yi aşağı yönde kestiğinde güçlü bir düşüş sinyali oluşur.',
      color: Color(0xFFFF6B6B),
      icon: Icons.trending_down,
    ),
    _FilterDef(
      id: 'Supertrend AL',
      label: 'Supertrend AL',
      subtitle: 'Koşul: Supertrend göstergesi yön değiştirerek AL sinyali üretir. Trendin başlangıcını yakalar.',
      color: Color(0xFF4CAF50),
      icon: Icons.bolt,
    ),
  ];

  static const List<_FilterDef> _momentumFilters = [
    _FilterDef(
      id: 'RSI 40',
      label: 'RSI 40 Altı',
      subtitle: 'Koşul: RSI değeri 40 ve altına düştüğünde aşırı satım bölgesine yaklaşılıyor demektir. Potansiyel dönüş noktası.',
      color: Color(0xFFAB47BC),
      icon: Icons.show_chart,
    ),
    _FilterDef(
      id: 'Supertrend SAT',
      label: 'Supertrend SAT',
      subtitle: 'Koşul: Supertrend göstergesi SAT sinyali üretir. Düşüş trendinin başlangıcını işaret eder.',
      color: Color(0xFFEF5350),
      icon: Icons.bolt_outlined,
    ),
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  List<_FilterDef> get _currentFilters =>
      _tabController.index == 0 ? _trendFilters : _momentumFilters;

  bool _matchFilter(AssetModel a) {
    switch (_selectedFilter) {
      case 'RSI 40':        return a.isRsiBelow40;
      case 'Golden Cross':  return a.isGoldenCross;
      case 'Death Cross':   return a.isDeathCross;
      case 'Supertrend AL': return a.isSupertrendBuy;
      case 'Supertrend SAT':return a.isSupertrendSell;
      case 'MACD Bullish':  return a.isMacdBullish;
      default: return false;
    }
  }

  Future<void> _startScan(String filterId) async {
    setState(() {
      _selectedFilter = filterId;
      _scanning = true;
      _results = [];
      _progress = 0;
      _total = _scanSymbols.length;
      _errorMsg = null;
    });
    try {
      final assets = await StockService.fetchMultiple(
        _scanSymbols, period: '6mo',
        onProgress: (done, total) {
          if (mounted) setState(() => _progress = done);
        },
      );
      final filtered = assets.where(_matchFilter).toList();
      if (mounted) setState(() { _results = filtered; _scanning = false; });
    } catch (e) {
      if (mounted) setState(() { _scanning = false; _errorMsg = 'Hata: $e'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF2F2F7),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Başlık
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
              child: Row(
                children: [
                  const Icon(Icons.menu, color: Colors.black54, size: 22),
                  const SizedBox(width: 8),
                  const Text('Tarama', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black87)),
                  const Spacer(),
                  if (_scanning)
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: Text('$_progress/$_total', style: const TextStyle(color: Colors.grey, fontSize: 12)),
                    ),
                  if (_scanning)
                    const SizedBox(width: 18, height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF34C759))),
                ],
              ),
            ),

            // Periyot + aktif bilgisi
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 6, 16, 10),
              child: Row(
                children: [
                  const Icon(Icons.access_time, color: Color(0xFF34C759), size: 14),
                  const SizedBox(width: 4),
                  const Text('Aktif Periyot: ', style: TextStyle(color: Colors.grey, fontSize: 12)),
                  Text(_periodLabel(_activePeriod),
                      style: const TextStyle(color: Color(0xFF34C759), fontSize: 12, fontWeight: FontWeight.bold)),
                ],
              ),
            ),

            // Periyot değiştir bar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: GestureDetector(
                onTap: _showPeriodSheet,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                  decoration: BoxDecoration(
                    color: const Color(0xFF34C759),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.tune, color: Colors.white, size: 16),
                      const SizedBox(width: 8),
                      const Text('Periyot Değiştir',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                      const Spacer(),
                      const Icon(Icons.keyboard_arrow_down, color: Colors.white, size: 20),
                    ],
                  ),
                ),
              ),
            ),

            const SizedBox(height: 12),

            // Tab: Trend / Momentum / Advanced
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: TabBar(
                  controller: _tabController,
                  onTap: (_) => setState(() {}),
                  indicator: BoxDecoration(
                    color: const Color(0xFF34C759),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  dividerColor: Colors.transparent,
                  indicatorSize: TabBarIndicatorSize.tab,
                  labelColor: Colors.white,
                  unselectedLabelColor: const Color(0xFF34C759),
                  labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                  tabs: const [Tab(text: 'Trend'), Tab(text: 'Momentum')],
                ),
              ),
            ),

            const SizedBox(height: 4),

            if (_scanning) ...[
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: LinearProgressIndicator(
                  value: _total > 0 ? _progress / _total : 0,
                  backgroundColor: Colors.grey.shade200,
                  color: const Color(0xFF34C759),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ],

            if (_errorMsg != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                child: Text(_errorMsg!, style: const TextStyle(color: Color(0xFFFF3B30), fontSize: 12)),
              ),

            // Liste: filtreler veya sonuçlar
            Expanded(
              child: _selectedFilter != null && _results.isNotEmpty
                  ? _buildResults()
                  : _buildFilterList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterList() {
    final filters = _currentFilters;
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      itemCount: filters.length,
      itemBuilder: (_, i) => _FilterCard(
        def: filters[i],
        isSelected: _selectedFilter == filters[i].id,
        onTap: () => _startScan(filters[i].id),
      ),
    );
  }

  Widget _buildResults() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
          child: Row(
            children: [
              Text('${_results.length} hisse bulundu',
                  style: const TextStyle(color: Colors.grey, fontSize: 12)),
              const Spacer(),
              GestureDetector(
                onTap: () => setState(() { _selectedFilter = null; _results = []; }),
                child: const Text('← Filtrelere Dön',
                    style: TextStyle(color: Color(0xFF34C759), fontSize: 12, fontWeight: FontWeight.w600)),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            itemCount: _results.length,
            itemBuilder: (_, i) => _ResultCard(asset: _results[i]),
          ),
        ),
      ],
    );
  }

  void _showPeriodSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Periyot Seç', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            ...['4S', 'G', 'H', 'A'].map((p) => ListTile(
              title: Text(_periodLabel(p)),
              trailing: _activePeriod == p
                  ? const Icon(Icons.check, color: Color(0xFF34C759)) : null,
              onTap: () {
                setState(() => _activePeriod = p);
                Navigator.pop(context);
              },
            )),
          ],
        ),
      ),
    );
  }

  String _periodLabel(String p) {
    switch (p) {
      case '4S': return '4 Saatlik';
      case 'G':  return '1 Gün';
      case 'H':  return '1 Hafta';
      case 'A':  return '1 Ay';
      default:   return p;
    }
  }
}

class _FilterDef {
  final String id, label, subtitle;
  final Color color;
  final IconData icon;
  const _FilterDef({required this.id, required this.label, required this.subtitle,
      required this.color, required this.icon});
}

class _FilterCard extends StatelessWidget {
  final _FilterDef def;
  final bool isSelected;
  final VoidCallback onTap;
  const _FilterCard({required this.def, required this.isSelected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: isSelected ? Border.all(color: def.color, width: 2) : null,
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 6)],
        ),
        child: Row(
          children: [
            Container(
              width: 48, height: 48,
              decoration: BoxDecoration(
                color: def.color,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(def.icon, color: Colors.white, size: 24),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(def.label, style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 15, color: Colors.black87)),
                  const SizedBox(height: 3),
                  Text(def.subtitle, style: const TextStyle(color: Colors.grey, fontSize: 11),
                      maxLines: 2, overflow: TextOverflow.ellipsis),
                ],
              ),
            ),
            const SizedBox(width: 8),
            const Icon(Icons.chevron_right, color: Colors.grey, size: 20),
          ],
        ),
      ),
    );
  }
}

class _ResultCard extends StatelessWidget {
  final AssetModel asset;
  const _ResultCard({required this.asset});

  @override
  Widget build(BuildContext context) {
    final isPos = asset.changePercent >= 0;
    final ema5val   = asset.ema(5);
    final ema20val  = asset.ema(20);
    final ema100val = asset.ema(100);
    final rsiVals   = asset.rsi();
    final currentRsi = rsiVals.isNotEmpty ? rsiVals.last : null;

    final badges = <_Badge>[];
    if (asset.isRsiBelow40 && currentRsi != null) {
      badges.add(_Badge(label: 'RSI ${currentRsi.toStringAsFixed(1)}', color: const Color(0xFFAB47BC)));
    }
    if (asset.isGoldenCross) badges.add(const _Badge(label: 'Golden Cross', color: Color(0xFF34C759)));
    if (asset.isDeathCross)  badges.add(const _Badge(label: 'Death Cross',  color: Color(0xFFFF3B30)));
    if (asset.isSupertrendBuy)  badges.add(const _Badge(label: 'ST AL',  color: Color(0xFF34C759)));
    if (asset.isSupertrendSell) badges.add(const _Badge(label: 'ST SAT', color: Color(0xFFFF3B30)));
    if (asset.isMacdBullish) badges.add(const _Badge(label: 'MACD ↑',   color: Color(0xFFFFB300)));

    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => BuyScreen(asset: asset)),
      ),
      child: Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 6)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(width: 8, height: 8,
                  decoration: BoxDecoration(
                    color: isPos ? const Color(0xFF34C759) : const Color(0xFFFF3B30),
                    shape: BoxShape.circle,
                  )),
              const SizedBox(width: 8),
              Expanded(child: Text(asset.symbol,
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17, color: Colors.black87))),
              Text('${asset.price.toStringAsFixed(2)} ₺',
                  style: TextStyle(
                    color: isPos ? const Color(0xFF34C759) : const Color(0xFFFF3B30),
                    fontWeight: FontWeight.bold, fontSize: 16,
                  )),
            ],
          ),
          if (asset.name != asset.symbol)
            Padding(
              padding: const EdgeInsets.only(left: 16, top: 1),
              child: Text(asset.name, style: const TextStyle(color: Colors.grey, fontSize: 11),
                  overflow: TextOverflow.ellipsis),
            ),
          const SizedBox(height: 10),
          const Divider(height: 1),
          const SizedBox(height: 10),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  _InfoRow(icon: Icons.bar_chart, iconColor: Colors.grey,
                      label: 'Hacim', value: _fmtVol(asset.avgVolume)),
                  const SizedBox(height: 5),
                  _InfoRow(icon: Icons.arrow_upward, iconColor: const Color(0xFF34C759),
                      label: '52H Yüksek', value: '${asset.high52w.toStringAsFixed(2)} ₺'),
                  const SizedBox(height: 5),
                  _InfoRow(icon: Icons.arrow_downward, iconColor: const Color(0xFFFF3B30),
                      label: '52H Düşük', value: '${asset.low52w.toStringAsFixed(2)} ₺'),
                ]),
              ),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                const Text('EMA Durumu', style: TextStyle(color: Colors.grey, fontSize: 11)),
                const SizedBox(height: 4),
                if (ema5val.isNotEmpty)   _EmaRow(label: 'EMA5',   emaVal: ema5val.last,   price: asset.price),
                if (ema20val.isNotEmpty)  _EmaRow(label: 'EMA20',  emaVal: ema20val.last,  price: asset.price),
                if (ema100val.isNotEmpty) _EmaRow(label: 'EMA100', emaVal: ema100val.last, price: asset.price),
              ]),
            ],
          ),
          if (badges.isNotEmpty) ...[
            const SizedBox(height: 8),
            Wrap(spacing: 6, runSpacing: 4, children: badges.map((b) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: b.color.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(5),
                border: Border.all(color: b.color.withValues(alpha: 0.4)),
              ),
              child: Text(b.label, style: TextStyle(color: b.color, fontSize: 10, fontWeight: FontWeight.bold)),
            )).toList()),
          ],
          Align(
            alignment: Alignment.centerRight,
            child: Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text('${isPos ? '+' : ''}${asset.changePercent.toStringAsFixed(2)}%',
                  style: TextStyle(
                    color: isPos ? const Color(0xFF34C759) : const Color(0xFFFF3B30),
                    fontSize: 12, fontWeight: FontWeight.w600,
                  )),
            ),
          ),
        ],
      ),
    ),  // GestureDetector kapanışı
    );
  }

  String _fmtVol(double v) {
    if (v >= 1e9) return '${(v / 1e9).toStringAsFixed(1)}B';
    if (v >= 1e6) return '${(v / 1e6).toStringAsFixed(1)}M';
    if (v >= 1e3) return '${(v / 1e3).toStringAsFixed(1)}K';
    return v.toStringAsFixed(0);
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon; final Color iconColor; final String label, value;
  const _InfoRow({required this.icon, required this.iconColor, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
    Icon(icon, color: iconColor, size: 13), const SizedBox(width: 3),
    Text('$label  ', style: const TextStyle(color: Colors.grey, fontSize: 11)),
    Text(value, style: const TextStyle(color: Colors.black87, fontSize: 11, fontWeight: FontWeight.w600)),
  ]);
}

class _EmaRow extends StatelessWidget {
  final String label; final double emaVal, price;
  const _EmaRow({required this.label, required this.emaVal, required this.price});
  @override
  Widget build(BuildContext context) {
    final above = price > emaVal;
    return Padding(padding: const EdgeInsets.only(bottom: 3), child: Row(mainAxisSize: MainAxisSize.min, children: [
      Text(label, style: const TextStyle(color: Colors.grey, fontSize: 11)),
      const SizedBox(width: 3),
      Icon(above ? Icons.arrow_upward : Icons.arrow_downward, size: 11,
          color: above ? const Color(0xFF34C759) : const Color(0xFFFF3B30)),
      const SizedBox(width: 2),
      Text(emaVal.toStringAsFixed(2), style: TextStyle(
          color: above ? const Color(0xFF34C759) : const Color(0xFFFF3B30),
          fontSize: 11, fontWeight: FontWeight.w600)),
    ]));
  }
}

class _Badge { final String label; final Color color; const _Badge({required this.label, required this.color}); }
